import calendar
import pprint
import datetime

month = input("Enter month  in number: ")

year = input("Enter year: ")


calendar.TextCalendar(calendar.SUNDAY).prmonth(year, month)