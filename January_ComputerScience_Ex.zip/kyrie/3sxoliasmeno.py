import string	#eisagoyme to module tis string gia na xrisimopoihsoyme tis 
						#sunartiseis maketrans kai translate


alp =  "ABCDEFGHIJKLMabcdefghijklmNOPQRSTUVWXYZnopqrstuvwxyz"
trs = "NOPQRSTUVWXYZnopqrstuvwxyzABCDEFGHIJKLMabcdefghijklm"
trantts = string.maketrans(alp,trs)	#h metavlith trantts metafrazei thn metavlith alp
														#sthn metavlith trs
	
x = raw_input("Enter string: ") #eisaghtimh o xrisths, xrisimopoioyme raw_input anti
											#gia sketo input gia na paroume typo string olh thn eisodo
	
print x.translate(trantts) #metafrazoyme thn metavlith x sumfwna me ton metafrasth
										 #trantts
	
