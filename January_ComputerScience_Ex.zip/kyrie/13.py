n = input("Enter number of digits: ")
s = input("Enter wished result: ")

t = 10**n
a = 0

def digSum( x):
    sum = 0
     
    while(x > 0 or sum > 9*n):
     
        if(x == 0):
            x = sum
            sum = 0
         
        sum += x % 10
        x /= 10
     
    return sum

if n <= s and s <10 * n:

	for i in range(t):
	
		arr = map(int, str(i))
	
		if len(arr) == n:
			if sorted(arr) == arr:
				if digSum(i) == s:
					print map(int,str(i)) 
			
					a += 1
				
				
if a == 0:
	print("No combinations found!")
else:
	print("%d combinations found!") % a
		
	
		


	
	
	
		
	


