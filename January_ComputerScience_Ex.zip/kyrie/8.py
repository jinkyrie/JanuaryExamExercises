import random
import itertools

a = 0
arr = [30]

for i in range(30):

	arr.append (random.randint(-30,30))
	
	
	
for i in range(27):
	
	for j in range(27):
		
		for k in range(27):
			
			if (arr[i] + arr[j+1] + arr[k+2]) == 0 :
				
				print arr[i],	  arr[j+1], arr[k+2]  
				
				a += 1

if a == 0:
	print "No combinations with sum of 0 found"
else:
	print "Total combinations with sum of 0 found: %s" %a