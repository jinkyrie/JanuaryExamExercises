import string


alp =  "ABCDEFGHIJKLMabcdefghijklmNOPQRSTUVWXYZnopqrstuvwxyz"
trs = "NOPQRSTUVWXYZnopqrstuvwxyzABCDEFGHIJKLMabcdefghijklm"
trantts = string.maketrans(alp,trs)
	
x = raw_input("Enter string: ")
	
print x.translate(trantts) 
	
